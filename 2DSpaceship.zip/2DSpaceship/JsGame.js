const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

//declare rocket size
const rocketWidth = 150;
const rocketHeight = 150;

//variables for current x,y position of rocket
let rocketX = canvas.width / 2 - rocketWidth / 2;
let rocketY = canvas.height / 2 - rocketHeight / 2;

//initialize speed of rocket
let rocketSpeed = 1.5;

//Establish variables for keeping track of the direction the rocket is heading (rocketAngle) and where the rocket is facing (rocketDirection)
let rocketAngle = 0;
let rocketDirection = 0;

//establish variable to keep track if the rocket is rotating and which way. 0 for not turning, 1 for left, and -1 for right
let isRotating = 0;

//establish variable for turning acceleration
let turningAcceleration = 0;

// Declare and initialize the backgroundStars array outside the function
let backgroundStars = [];

// Create a 2D array to keep track of added pixels
const addedPixels = new Array(canvas.width).fill(null).map(() => new Array(canvas.height).fill(false));

//let photonBeams = [];

//Load sprite for no flames
const noFlamesImage = new Image();
noFlamesImage.src = "Vector125x125/NoFlames.gif";

//Load sprite sheet images for left
const leftSpaceGIF = new Image();
leftSpaceGIF.src = "Vector125x125/LeftFlameSpriteSheet.png";

//Load sprite sheet images for right
const rightSpaceGIF = new Image();
rightSpaceGIF.src = "Vector125x125/RightFlameSpriteSheet.png";

//Load sprite sheet images for both
const bothFlamesImage = new Image();
bothFlamesImage.src = "Vector125x125/BothFlamesSpriteSheet.png";


// Load the "WhiteStar" sprite sheet image
const whiteStarImage = new Image();
whiteStarImage.src = "Vector125x125/WhiteStarSpriteSheet.png";

//const photonBeam = new Image();
//photonBeam.src = "Vector125x125/photonBeam1.png";

//initialize rocket
let currentImage = noFlamesImage;
let currentFrame = 0;
const frameCount = 4;
const frameWidth = rocketWidth;
const frameHeight = rocketHeight;

let starDelay = 0
let nearStar = 0;

//initialize buttons
const KEY_LEFT = 37;
const KEY_A = 65;
const KEY_RIGHT = 39;
const KEY_D = 68;
const KEY_W = 87;
const KEY_UP = 38;
const KEY_SPACE = 32;
const KEY_ENTER = 13;

//set key states to false initially
const keyState = {
    left: false,
    right: false,
    up: false,
    space: false,
    enter: false,
};

//function for checking if key is pressed
document.addEventListener("keydown", (event) => {
    const keyPressed = event.keyCode;
    if (keyPressed === KEY_LEFT || keyPressed === KEY_A) {
        keyState.left = true;
    } else if (keyPressed === KEY_RIGHT || keyPressed === KEY_D) {
        keyState.right = true;
    } else if (keyPressed === KEY_W || keyPressed === KEY_UP) {
        keyState.up = true;
    } else if (keyPressed === KEY_SPACE) {
        keyState.space = true;
    } else if (keyPressed === KEY_ENTER) {
        keyState.enter = true;
    }
});

//function for checking if key is not pressed
document.addEventListener("keyup", (event) => {
    const keyReleased = event.keyCode;
    if (keyReleased === KEY_LEFT || keyReleased === KEY_A) {
        keyState.left = false;
    } else if (keyReleased === KEY_RIGHT || keyReleased === KEY_D) {
        keyState.right = false;
    } else if (keyReleased === KEY_W || keyReleased === KEY_UP) {
        keyState.up = false;
    } else if (keyReleased === KEY_SPACE) {
        keyState.space = false;
    } else if (keyReleased === KEY_ENTER) {
        keyState.enter = false;
    }
});

//draws rocket
function drawRocket() {
    //focus ctx on the rockets position and then rotate rocket to face rocketDirection
    ctx.save();
    ctx.translate(rocketX + rocketWidth / 2, rocketY + rocketHeight / 2);
    ctx.rotate((Math.PI / 180) * rocketDirection);

    //Only update the current frame if not using noFlamesImage
    if (currentImage !== noFlamesImage) {
        //update through sprite sheet
        const frame = currentFrame * frameWidth;
        ctx.drawImage(currentImage, frame, 0, frameWidth, frameHeight, -rocketWidth / 2, -rocketHeight / 2, rocketWidth, rocketHeight);
    } else {
        //For noFlamesImage, draw the static image
        ctx.drawImage(currentImage, -rocketWidth / 2, -rocketHeight / 2, rocketWidth, rocketHeight);
    }

    ctx.restore();

    /*
    // Draw the photon beams
    for (const beam of photonBeams) {
        ctx.save();
        ctx.translate(beam.x, beam.y);
        ctx.rotate((Math.PI / 180) * beam.direction); // Apply the photon beam's direction
        ctx.drawImage(photonBeam, -beam.width / 2, -beam.height / 2, beam.width, beam.height);
        ctx.restore();
    }
     */
}

//update position of rocket
function updateRocketPosition() {
    //get the change of the rocket based on the speed and angle the rocket is heading
    const velocityX = rocketSpeed * Math.sin((Math.PI / 180) * rocketAngle);
    const velocityY = -rocketSpeed * Math.cos((Math.PI / 180) * rocketAngle);

    //update the position of rocket
    rocketX += velocityX;
    rocketY += velocityY;

    //check if rocket is out of bounds
    const boundaryOffset = canvas.width * 0.25; // Set a boundary offset to be 25% of the canvas width

    //check if rocket is offscreen
    if (
        rocketY + rocketHeight / 2 <= -boundaryOffset ||
        rocketY - rocketHeight / 2 >= canvas.height + boundaryOffset ||
        rocketX + rocketWidth / 2 <= -boundaryOffset ||
        rocketX - rocketWidth / 2 >= canvas.width + boundaryOffset
    ) {
        //reposition the rocket back to center
        rocketX = canvas.width / 2 - rocketWidth / 2;
        rocketY = canvas.height / 2 - rocketHeight / 2;
    }
}

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}


// This function generates the background and draws it on the canvas
function generateBackground() {
    // Traverse all the pixels on the canvas
    for (let x = 0; x < canvas.width; x++) {
        for (let y = 0; y < canvas.height; y++) {
            // Check if the current (x, y) pixel is already added
            const isPixelAdded = addedPixels[x][y];

            // If the pixel is not added, add it and set its 'valid' property to true approximately 1 in 100 pixels
            if (!isPixelAdded) {
                if (nearStar > 1) {
                    const isValidPixel = false; // Set isValidPixel to false if nearStar is 1
                    backgroundStars.push({
                        x: x,
                        y: y,
                        valid: isValidPixel,
                        spriteSheet: whiteStarImage,
                        currentFrame: 0 // Initialize the currentFrame property to 0
                    });
                    addedPixels[x][y] = true; // Mark the pixel as added in the addedPixels array
                    nearStar--
                } else {
                    const isValidPixel = Math.random() < 0.00025; // Set to true with a probability of 1 in 100 (0.01)

                    if(isValidPixel){
                      nearStar = 2000
                    }

                    backgroundStars.push({
                        x: x,
                        y: y,
                        valid: isValidPixel,
                        spriteSheet: whiteStarImage,
                        currentFrame: 0 // Initialize the currentFrame property to 0
                    });
                    addedPixels[x][y] = true; // Mark the pixel as added in the addedPixels array
                }
            }
        }
    }

    // After traversing, you can put your background generation logic here
    // For example, drawing stars, celestial bodies, or other elements
    // For now, let's keep it simple and just draw a solid color background and white pixels
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw the stars using the new sprite sheet
    for (const star of backgroundStars) {
        if (star.valid) {
            // Calculate the X position of the current frame
            const frameX = star.currentFrame * 7; // Assuming each frame is 7x7 pixels

            // Draw the star with the current frame
            ctx.drawImage(star.spriteSheet, frameX, 0, 7, 7, star.x, star.y, 7, 7);

            if(starDelay == 8) {
                // Update the current frame for the next iteration
                star.currentFrame = (star.currentFrame + 1) % 7; // Assuming `numberOfFrames` is the total frames in the sprite sheet
                starDelay = 0;
            }
            else{
                starDelay++;
            }
        }
    }
}

/*
function firePhotonBeam() {
    const beamWidth = 2;
    const beamHeight = 6;
    const beamSpeed = 5;

    // Calculate the initial position of the photon beam at the center of the rocket
    const rocketCenterX = rocketX + rocketWidth / 2;
    const rocketCenterY = rocketY + rocketHeight / 2;

    // Calculate the offsets based on the rocket's direction using trigonometry
    const offsetX = 15 * Math.cos((Math.PI / 180) * rocketDirection);
    const offsetY = 15 * Math.sin((Math.PI / 180) * rocketDirection);

    // Calculate the position of the first photon beam
    const beamX1 = rocketCenterX - beamWidth / 2 + offsetX;
    const beamY1 = rocketCenterY - beamHeight / 2 + offsetY + 4; // Move the first beam down by 4 pixels

    console.log(beamX1);
    console.log(beamY1);

    // Create the first photon beam object
    const beam1 = {
        x: beamX1,
        y: beamY1,
        width: beamWidth,
        height: beamHeight,
        speed: beamSpeed,
        direction: rocketDirection, // Store the current rocket direction in the beam object
    };

    // Add the first beam to the photonBeams array
    photonBeams.push(beam1);

    // Calculate the position of the second photon beam on the other side of the wing
    const beamX2 = rocketCenterX - beamWidth / 2 - offsetX + 2; // Apply negative offset to the X position
    const beamY2 = rocketCenterY - beamHeight / 2 - offsetY + 4; // Move the second beam down by 4 pixels
    const beamDirection2 = rocketDirection; // The second beam follows the same direction as the rocket

    console.log(beamX2);
    console.log(beamY2);

    // Create the second photon beam object
    const beam2 = {
        x: beamX2,
        y: beamY2,
        width: beamWidth,
        height: beamHeight,
        speed: beamSpeed,
        direction: beamDirection2, // Store the current rocket direction in the beam object
    };

    // Add the second beam to the photonBeams array
    photonBeams.push(beam2);
}
 */

/*
function updatePhotonBeams() {
    for (const beam of photonBeams) {
        // Calculate horizontal and vertical components of beam's movement
        const velocityX = beam.speed * Math.sin((Math.PI / 180) * beam.direction);
        const velocityY = -beam.speed * Math.cos((Math.PI / 180) * beam.direction);

        // Update the beam's position
        beam.x += velocityX;
        beam.y += velocityY;
    }
}

 */

function gameLoop() {
    clearCanvas();

    generateBackground();

    if (keyState.left) {
        //check if we were rotating the other way
        if (isRotating === -1) {
            //change the position the rocket needs to head to where the rocket is facing
            rocketAngle = rocketDirection;
        }
        //check if we are already in a turn
        else if (isRotating === 1) {
            //check if we haven't hit the max turning acceleration
            if(turningAcceleration >= -3) {
                //check if we're deaccelerating and if so turn faster
                if(turningAcceleration > 0){
                    turningAcceleration -= .30;
                }
                //increase acceleration to left
                turningAcceleration -= .15;
            }
            else{
                turningAcceleration = -3;
            }

            //change the position the rocket needs to head to where the rocket is facing
            rocketAngle = rocketDirection;
        }

        //readjust the angle and then set the direction to the angle we're now heading
        rocketAngle += turningAcceleration;
        rocketDirection = rocketAngle;

        //set isRotating to left
        isRotating = 1;

        //set the image to turning left
        currentImage = leftSpaceGIF;
    }
    else if (keyState.right) {
        //check if we were rotating the other way
        if (isRotating === 1) {
            //change the position the rocket needs to head to where the rocket is facing
            rocketAngle = rocketDirection;
        }
        //check if we are already in a turn
        else if (isRotating === -1) {
            //check if we haven't hit the max turning acceleration
            if(turningAcceleration <= 3) {
                //check if we're deaccelerating and if so turn faster
                if(turningAcceleration < 0){
                    turningAcceleration += .30
                }
                //increase acceleration to the right
                turningAcceleration += .15
            }
            //change the position the rocket needs to head to where the rocket is facing
            rocketAngle = rocketDirection;
        }

        //readjust the angle and then set the direction to the angle we're now heading
        rocketAngle += turningAcceleration;
        rocketDirection = rocketAngle;

        //set isRotating to right
        isRotating = -1;

        //set the image to turning right
        currentImage = rightSpaceGIF;
    }
    else if (keyState.up) {
        //reset turning acceleration and isRotating
        turningAcceleration = 0;
        isRotating = 0;

        //set the angle we're travelling to where we're facing
        rocketAngle = rocketDirection;

        //set the image to both flames
        currentImage = bothFlamesImage;
    }
    else {
        //check if we're turning while floating and readjust rocketDirection so we still spin
        if (isRotating === 1) {
            rocketDirection += turningAcceleration;
        } else if (isRotating === -1) {
            rocketDirection += turningAcceleration;
        }
        //set hte image to no flames
        currentImage = noFlamesImage;
    }

    // Update the current frame index to animate the sprite
    currentFrame = (currentFrame + 1) % frameCount;

    /*
    if (keyState.space || keyState.enter) {
        firePhotonBeam();
    }

     */

    updateRocketPosition();
    //updatePhotonBeams();
    drawRocket();
    requestAnimationFrame(gameLoop);
}

gameLoop();

